<?php

/**
 * Plugin Name:         Purehearts Companion Plugin
 * Plugin URI:          https://www.github.com/fayekalvi/
 * Description:         Purehearts Theme's Companion Plugin.
 * Version:             1.0.0
 * Author:              Fayek Alvi Rahman Jaki
 * Author URI:          https://www.github.com/fayekalvi/
 * Text Domain:         pcp
 * Domain Path:         /languages/
 * License:             GNU General Public License v2.0 or later
 * License URI:         http://www.gnu.org/licenses/gpl-2.0.txt
 * Requires at least:   5.2
 * Tested up to:        6.0
 *
 *
 */

function pcp_register_my_cpts_service()
{

    /**
     * Post Type: Books.
     */

    $labels = [
        "name" => esc_html__("Services", "purehearts"),
        "singular_name" => esc_html__("Service", "purehearts"),
        "menu_name" => esc_html__("Services", "purehearts"),
        "all_items" => esc_html__("All Services", "purehearts"),
        "add_new" => esc_html__("Add New", "purehearts"),
        "add_new_item" => esc_html__("Add New Services", "purehearts"),
    ];

    $args = [
        "label" => esc_html__("Services", "purehearts"),
        "labels" => $labels,
        "description" => "",
        "public" => true,
        "publicly_queryable" => true,
        "show_ui" => true,
        "show_in_rest" => true,
        "rest_base" => "",
        "rest_controller_class" => "WP_REST_Posts_Controller",
        "rest_namespace" => "wp/v2",
        "has_archive" => false,
        "show_in_menu" => true,
        "show_in_nav_menus" => true,
        "delete_with_user" => false,
        "exclude_from_search" => false,
        "capability_type" => "post",
        "map_meta_cap" => true,
        "hierarchical" => false,
        "can_export" => false,
        "rewrite" => ["slug" => "service", "with_front" => true],
        "query_var" => true,
        "supports" => ["title", "editor", "thumbnail", "excerpt", "custom-fields", "comments", "author"],
        "taxonomies" => ["category"],
        "show_in_graphql" => false,
    ];

    register_post_type("service", $args);
}

add_action('init', 'pcp_register_my_cpts_service');
